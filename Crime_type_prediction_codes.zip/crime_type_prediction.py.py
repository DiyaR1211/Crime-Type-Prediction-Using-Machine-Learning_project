# Import libraries
import textwrap 
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder as OHE
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

# Import CSV file
data_district = pd.read_csv("C:\\Users\\diyar\\OneDrive\\Desktop\\DATASETS\\CRIME Project\\01_District_wise_crimes_committed_IPC_2001_2012.csv")

# Convert all column names to uppercase to prevent mismatch issues
data_district.columns = data_district.columns.str.upper()

# Convert string columns to title case and strip spaces
data_district["STATE/UT"] = data_district["STATE/UT"].str.strip().str.title()
data_district["DISTRICT"] = data_district["DISTRICT"].str.strip().str.title()

# Combine similar crime categories
data_district['ROBBERY & THEFT'] = (
    data_district['DACOITY'] + data_district["PREPARATION AND ASSEMBLY FOR DACOITY"] +
    data_district["ROBBERY"] + data_district['BURGLARY'] +
    data_district["THEFT"] + data_district['AUTO THEFT'] + data_district['OTHER THEFT']
)

data_district['VIOLENCE AGAINST WOMEN'] = (
    data_district['DOWRY DEATHS'] + data_district['ASSAULT ON WOMEN WITH INTENT TO OUTRAGE HER MODESTY'] +
    data_district["INSULT TO MODESTY OF WOMEN"] + data_district["CRUELTY BY HUSBAND OR HIS RELATIVES"]
)

data_district["FRAUD & FINANCIAL CRIMES"] = (
    data_district["CRIMINAL BREACH OF TRUST"] + data_district["CHEATING"] + data_district["COUNTERFIETING"]
)

data_district["OTHER CRIMES"] = (
    data_district["RIOTS"] + data_district["ARSON"] + data_district["HURT/GREVIOUS HURT"] +
    data_district["IMPORTATION OF GIRLS FROM FOREIGN COUNTRIES"] + 
    data_district["CAUSING DEATH BY NEGLIGENCE"] + data_district["OTHER IPC CRIMES"]
)


# Drop original columns that were combined
columns_drop = [
    "MURDER", "ATTEMPT TO MURDER", "CULPABLE HOMICIDE NOT AMOUNTING TO MURDER", 
    "KIDNAPPING & ABDUCTION", "KIDNAPPING AND ABDUCTION OF WOMEN AND GIRLS", "KIDNAPPING AND ABDUCTION OF OTHERS",
    "RAPE", "OTHER RAPE", "DACOITY", "PREPARATION AND ASSEMBLY FOR DACOITY", "ROBBERY", "BURGLARY", 
    "THEFT", "AUTO THEFT", "OTHER THEFT", "DOWRY DEATHS", "ASSAULT ON WOMEN WITH INTENT TO OUTRAGE HER MODESTY", 
    "INSULT TO MODESTY OF WOMEN", "CRUELTY BY HUSBAND OR HIS RELATIVES", "CRIMINAL BREACH OF TRUST", 
    "CHEATING", "COUNTERFIETING", "RIOTS", "ARSON", "HURT/GREVIOUS HURT", 
    "IMPORTATION OF GIRLS FROM FOREIGN COUNTRIES", "CAUSING DEATH BY NEGLIGENCE", "OTHER IPC CRIMES",
    "TOTAL IPC CRIMES"]

data_district.drop(columns=columns_drop, inplace=True)
data_district = data_district[data_district["DISTRICT"] != "Total"]

# removing duplicate rows from each state
# Andra Pradesh
#Hydrabad
mask_andra1 = data_district["DISTRICT"].isin(["Hyderabad City", "Cyberabad", "Secunderabad Rly."])
mean_values_andra1 = data_district[mask_andra1].mean(numeric_only=True)

new_row_andra1 = pd.DataFrame([{
    'STATE/UT':'Andhra Pradesh',
    'DISTRICT':'Hyderabad City',
    **mean_values_andra1.to_dict()
}])

data_district = data_district[~mask_andra1]
data_district = pd.concat([data_district, new_row_andra1],ignore_index= True)
#warangal
mask_andra2 = data_district["DISTRICT"].isin(["Warangal", "Warangal Urban"])
mean_values_andra2 = data_district[mask_andra2].mean(numeric_only=True)

new_row_andra2 = pd.DataFrame([{
    'STATE/UT':'Andhra Pradesh',
    'DISTRICT':"Warangal",
    **mean_values_andra2.to_dict()
}])

data_district = data_district[~mask_andra2]
data_district = pd.concat([data_district, new_row_andra2],ignore_index= True)
# Guntur
mask_andra3 = data_district["DISTRICT"].isin(["Guntur", "Guntur Urban"])
mean_values_andra3 = data_district[mask_andra3].mean(numeric_only=True)

new_row_andra3 = pd.DataFrame([{
    'STATE/UT':'Andhra Pradesh',
    'DISTRICT':"Guntur",
    **mean_values_andra3.to_dict()
}])

data_district = data_district[~mask_andra3]
data_district = pd.concat([data_district, new_row_andra3],ignore_index= True)
#Vijaywada
mask_andra4 = data_district["DISTRICT"].isin(["Vijayawada", "Vijayawada City", "Vijayawada Rly."])
mean_values_andra4 = data_district[mask_andra4].mean(numeric_only=True)

new_row_andra4 = pd.DataFrame([{
    'STATE/UT':'Andhra Pradesh',
    'DISTRICT':"Vijayawada",
    **mean_values_andra4.to_dict()
}])

data_district = data_district[~mask_andra4]
data_district = pd.concat([data_district, new_row_andra4],ignore_index= True)
# vishakhapatnam
mask_andra5 = data_district["DISTRICT"].isin(["Visakhapatnam", "Visakha Rural"])
mean_values_andra5 = data_district[mask_andra5].mean(numeric_only=True)

new_row_andra5 = pd.DataFrame([{
    'STATE/UT':'Andhra Pradesh',
    'DISTRICT':"Visakhapatnam",
    **mean_values_andra5.to_dict()
}])

data_district = data_district[~mask_andra5]
data_district = pd.concat([data_district, new_row_andra5],ignore_index= True)

#arunachal
#kameng
mask_arunachal1 = data_district["DISTRICT"].isin(["Kameng East", "Kameng West"])
mean_values_arunachal1= data_district[mask_arunachal1].mean(numeric_only=True)

new_row_arunachal1 = pd.DataFrame([{
    'STATE/UT':'Arunachal Pradesh',
    'DISTRICT':"Kameng",
    **mean_values_arunachal1.to_dict()
}])

data_district = data_district[~mask_arunachal1]
data_district = pd.concat([data_district, new_row_arunachal1],ignore_index= True)
#siang
mask_arunachal2 = data_district["DISTRICT"].isin(["Siang East", "Siang West", "Siang Upper"])
mean_values_arunachal2= data_district[mask_arunachal2].mean(numeric_only=True)

new_row_arunachal2 = pd.DataFrame([{
    'STATE/UT':'Arunachal Pradesh',
    'DISTRICT':"Siang",
    **mean_values_arunachal2.to_dict()
}])

data_district = data_district[~mask_arunachal2]
data_district = pd.concat([data_district, new_row_arunachal2],ignore_index= True)
#subansiri
mask_arunachal3 = data_district["DISTRICT"].isin(["Subansiri Lower", "Subansiri Upper"])
mean_values_arunachal3= data_district[mask_arunachal3].mean(numeric_only=True)

new_row_arunachal3 = pd.DataFrame([{
    'STATE/UT':'Arunachal Pradesh',
    'DISTRICT':"Subansiri",
    **mean_values_arunachal3.to_dict()
}])

data_district = data_district[~mask_arunachal3]
data_district = pd.concat([data_district, new_row_arunachal3],ignore_index= True)
#dibang
mask_arunachal4 = data_district["DISTRICT"].isin(["Dibang Valley", "Upper Dibang Valley"])
mean_values_arunachal4= data_district[mask_arunachal4].mean(numeric_only=True)

new_row_arunachal4 = pd.DataFrame([{
    'STATE/UT':'Arunachal Pradesh',
    'DISTRICT':"Dibang Valley",
    **mean_values_arunachal4.to_dict()
}])

data_district = data_district[~mask_arunachal4]
data_district = pd.concat([data_district, new_row_arunachal4],ignore_index= True)

#Assam
#baksa
mask_assam1 = data_district["DISTRICT"].isin(["Baksa", "Baska"])
mean_values_assam1= data_district[mask_assam1].mean(numeric_only=True)

new_row_assam1 = pd.DataFrame([{
    'STATE/UT':'Assam',
    'DISTRICT':"Baksa",
    **mean_values_assam1.to_dict()
}])

data_district = data_district[~mask_assam1]
data_district = pd.concat([data_district, new_row_assam1],ignore_index= True)

#CID
mask_assam2 = data_district["DISTRICT"].isin(["C.I.D.", "G.R.P.", "R.P.O."])
mean_values_assam2= data_district[mask_assam2].mean(numeric_only=True)

new_row_assam2 = pd.DataFrame([{
    'STATE/UT':'Assam',
    'DISTRICT':"Railway & CID",
    **mean_values_assam2.to_dict()
}])

data_district = data_district[~mask_assam2]
data_district = pd.concat([data_district, new_row_assam2],ignore_index= True)


#BIHAR
#Katihar
mask_bihar1 = data_district["DISTRICT"].isin(["Katihar", "Katihar Rly."])
mean_values_bihar1= data_district[mask_bihar1].mean(numeric_only=True)

new_row_bihar1 = pd.DataFrame([{
    'STATE/UT':'Bihar',
    'DISTRICT':"Katihar",
    **mean_values_bihar1.to_dict()
}])

data_district = data_district[~mask_bihar1]
data_district = pd.concat([data_district, new_row_bihar1],ignore_index= True)
#Muzaffarpur
mask_bihar2 = data_district["DISTRICT"].isin(["Muzaffarpur", "Muzaffarpur Rly."])
mean_values_bihar2= data_district[mask_bihar2].mean(numeric_only=True)

new_row_bihar2 = pd.DataFrame([{
    'STATE/UT':'Bihar',
    'DISTRICT':"Muzaffarpur",
    **mean_values_bihar2.to_dict()
}])

data_district = data_district[~mask_bihar2]
data_district = pd.concat([data_district, new_row_bihar2],ignore_index= True)
#Munger
mask_bihar3 = data_district["DISTRICT"].isin(["Munger", "Jamalpur Rly."])
mean_values_bihar3= data_district[mask_bihar3].mean(numeric_only=True)

new_row_bihar3 = pd.DataFrame([{
    'STATE/UT':'Bihar',
    'DISTRICT':"Munger",
    **mean_values_bihar3.to_dict()
}])

data_district = data_district[~mask_bihar3]
data_district = pd.concat([data_district, new_row_bihar3],ignore_index= True)
#Patna
mask_bihar4 = data_district["DISTRICT"].isin(["Patna", "Patna Rly."])
mean_values_bihar4= data_district[mask_bihar4].mean(numeric_only=True)

new_row_bihar4 = pd.DataFrame([{
    'STATE/UT':'Bihar',
    'DISTRICT':"Patna",
    **mean_values_bihar4.to_dict()
}])

data_district = data_district[~mask_bihar4]
data_district = pd.concat([data_district, new_row_bihar4],ignore_index= True)

#CHHATTISGARH
# Balod
mask_chhattisgarh1 = data_district["DISTRICT"].isin(["Balod", "Baloda Bazar"])
mean_values_chhattisgarh1 = data_district[mask_chhattisgarh1].mean(numeric_only=True)

new_row_chhattisgarh1 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Balod",
    **mean_values_chhattisgarh1.to_dict()
}])

data_district = data_district[~mask_chhattisgarh1]
data_district = pd.concat([data_district, new_row_chhattisgarh1], ignore_index=True)

# Bilaspur
mask_chhattisgarh2 = data_district["DISTRICT"].isin(["Bilaspur", "Bilaspur Urban"])
mean_values_chhattisgarh2 = data_district[mask_chhattisgarh2].mean(numeric_only=True)

new_row_chhattisgarh2 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Bilaspur",
    **mean_values_chhattisgarh2.to_dict()
}])

data_district = data_district[~mask_chhattisgarh2]
data_district = pd.concat([data_district, new_row_chhattisgarh2], ignore_index=True)

# Dantewada
mask_chhattisgarh3 = data_district["DISTRICT"].isin(["Dantewara", "Bijapur"])
mean_values_chhattisgarh3 = data_district[mask_chhattisgarh3].mean(numeric_only=True)

new_row_chhattisgarh3 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Dantewada",
    **mean_values_chhattisgarh3.to_dict()
}])

data_district = data_district[~mask_chhattisgarh3]
data_district = pd.concat([data_district, new_row_chhattisgarh3], ignore_index=True)

# Durg
mask_chhattisgarh4 = data_district["DISTRICT"].isin(["Durg", "Bemetara"])
mean_values_chhattisgarh4 = data_district[mask_chhattisgarh4].mean(numeric_only=True)

new_row_chhattisgarh4 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Durg",
    **mean_values_chhattisgarh4.to_dict()
}])

data_district = data_district[~mask_chhattisgarh4]
data_district = pd.concat([data_district, new_row_chhattisgarh4], ignore_index=True)

# Raipur
mask_chhattisgarh5 = data_district["DISTRICT"].isin(["Raipur", "Grp Raipur"])
mean_values_chhattisgarh5 = data_district[mask_chhattisgarh5].mean(numeric_only=True)

new_row_chhattisgarh5 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Raipur",
    **mean_values_chhattisgarh5.to_dict()
}])

data_district = data_district[~mask_chhattisgarh5]
data_district = pd.concat([data_district, new_row_chhattisgarh5], ignore_index=True)

# Jagdalpur
mask_chhattisgarh6 = data_district["DISTRICT"].isin(["Jagdalpur", "Kondagaon"])
mean_values_chhattisgarh6 = data_district[mask_chhattisgarh6].mean(numeric_only=True)

new_row_chhattisgarh6 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Jagdalpur",
    **mean_values_chhattisgarh6.to_dict()
}])

data_district = data_district[~mask_chhattisgarh6]
data_district = pd.concat([data_district, new_row_chhattisgarh6], ignore_index=True)

# Raigarh
mask_chhattisgarh7 = data_district["DISTRICT"].isin(["Raigarh", "Korba"])
mean_values_chhattisgarh7 = data_district[mask_chhattisgarh7].mean(numeric_only=True)

new_row_chhattisgarh7 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Raigarh",
    **mean_values_chhattisgarh7.to_dict()
}])

data_district = data_district[~mask_chhattisgarh7]
data_district = pd.concat([data_district, new_row_chhattisgarh7], ignore_index=True)

# Sarguja
mask_chhattisgarh8 = data_district["DISTRICT"].isin(["Sarguja", "Surajpur"])
mean_values_chhattisgarh8 = data_district[mask_chhattisgarh8].mean(numeric_only=True)

new_row_chhattisgarh8 = pd.DataFrame([{
    'STATE/UT': 'Chhattisgarh',
    'DISTRICT': "Sarguja",
    **mean_values_chhattisgarh8.to_dict()
}])

data_district = data_district[~mask_chhattisgarh8]
data_district = pd.concat([data_district, new_row_chhattisgarh8], ignore_index=True)

# Gujarat
# Ahmedabad
mask_gujarat1 = data_district["DISTRICT"].isin(["Ahmedabad Commr.", "Ahmedabad Rural"])
mean_values_gujarat1 = data_district[mask_gujarat1].mean(numeric_only=True)

new_row_gujarat1 = pd.DataFrame([{
    'STATE/UT': 'Gujarat',
    'DISTRICT': "Ahmedabad",
    **mean_values_gujarat1.to_dict()
}])

data_district = data_district[~mask_gujarat1]
data_district = pd.concat([data_district, new_row_gujarat1], ignore_index=True)

# Kutch
mask_gujarat2 = data_district["DISTRICT"].isin(["Kutch", "Kutch (East(G))", "Kutch (West-Bhuj)"])
mean_values_gujarat2 = data_district[mask_gujarat2].mean(numeric_only=True)

new_row_gujarat2 = pd.DataFrame([{
    'STATE/UT': 'Gujarat',
    'DISTRICT': "Kutch",
    **mean_values_gujarat2.to_dict()
}])

data_district = data_district[~mask_gujarat2]
data_district = pd.concat([data_district, new_row_gujarat2], ignore_index=True)

# Rajkot
mask_gujarat3 = data_district["DISTRICT"].isin(["Rajkot Commr.", "Rajkot Rural"])
mean_values_gujarat3 = data_district[mask_gujarat3].mean(numeric_only=True)

new_row_gujarat3 = pd.DataFrame([{
    'STATE/UT': 'Gujarat',
    'DISTRICT': "Rajkot",
    **mean_values_gujarat3.to_dict()
}])

data_district = data_district[~mask_gujarat3]
data_district = pd.concat([data_district, new_row_gujarat3], ignore_index=True)

# Surat
mask_gujarat4 = data_district["DISTRICT"].isin(["Surat Commr.", "Surat Rural"])
mean_values_gujarat4 = data_district[mask_gujarat4].mean(numeric_only=True)

new_row_gujarat4 = pd.DataFrame([{
    'STATE/UT': 'Gujarat',
    'DISTRICT': "Surat",
    **mean_values_gujarat4.to_dict()
}])

data_district = data_district[~mask_gujarat4]
data_district = pd.concat([data_district, new_row_gujarat4], ignore_index=True)

# Vadodara
mask_gujarat5 = data_district["DISTRICT"].isin(["Vadodara Commr.", "Vadodara Rural"])
mean_values_gujarat5 = data_district[mask_gujarat5].mean(numeric_only=True)

new_row_gujarat5 = pd.DataFrame([{
    'STATE/UT': 'Gujarat',
    'DISTRICT': "Vadodara",
    **mean_values_gujarat5.to_dict()
}])

data_district = data_district[~mask_gujarat5]
data_district = pd.concat([data_district, new_row_gujarat5], ignore_index=True)

# Western Railway
mask_gujarat6 = data_district["DISTRICT"].isin(["W.Rly", "W.Rly Ahmedabad", "W.Rly Vadodara"])
mean_values_gujarat6 = data_district[mask_gujarat6].mean(numeric_only=True)

new_row_gujarat6 = pd.DataFrame([{
    'STATE/UT': 'Gujarat',
    'DISTRICT': "Western Railway",
    **mean_values_gujarat6.to_dict()
}])

data_district = data_district[~mask_gujarat6]
data_district = pd.concat([data_district, new_row_gujarat6], ignore_index=True)

# Haryana
# Ambala
mask_haryana1 = data_district["DISTRICT"].isin(["Ambala", "Ambala Rural", "Ambala Urban"])
mean_values_haryana1 = data_district[mask_haryana1].mean(numeric_only=True)

new_row_haryana1 = pd.DataFrame([{
    'STATE/UT': 'Haryana',
    'DISTRICT': "Ambala",
    **mean_values_haryana1.to_dict()
}])

data_district = data_district[~mask_haryana1]
data_district = pd.concat([data_district, new_row_haryana1], ignore_index=True)

# Hissar
mask_haryana2 = data_district["DISTRICT"].isin(["Hissar", "Hisar"])
mean_values_haryana2 = data_district[mask_haryana2].mean(numeric_only=True)

new_row_haryana2 = pd.DataFrame([{
    'STATE/UT': 'Haryana',
    'DISTRICT': "Hissar",
    **mean_values_haryana2.to_dict()
}])

data_district = data_district[~mask_haryana2]
data_district = pd.concat([data_district, new_row_haryana2], ignore_index=True)

# Gurgaon
mask_haryana3 = data_district["DISTRICT"].isin(["Gurgaon", "Gurugram"])
mean_values_haryana3 = data_district[mask_haryana3].mean(numeric_only=True)

new_row_haryana3 = pd.DataFrame([{
    'STATE/UT': 'Haryana',
    'DISTRICT': "Gurgaon",
    **mean_values_haryana3.to_dict()
}])

data_district = data_district[~mask_haryana3]
data_district = pd.concat([data_district, new_row_haryana3], ignore_index=True)

# Grp
mask_haryana4 = data_district["DISTRICT"].isin(["Grp", "GRP Haryana"])
mean_values_haryana4 = data_district[mask_haryana4].mean(numeric_only=True)

new_row_haryana4 = pd.DataFrame([{
    'STATE/UT': 'Haryana',
    'DISTRICT': "Grp",
    **mean_values_haryana4.to_dict()
}])

data_district = data_district[~mask_haryana4]
data_district = pd.concat([data_district, new_row_haryana4], ignore_index=True)

# Himachal Pradesh
# Baddi
mask_hp1 = data_district["DISTRICT"].isin(["Baddipolicedist", "Baddi Police District"])
mean_values_hp1 = data_district[mask_hp1].mean(numeric_only=True)

new_row_hp1 = pd.DataFrame([{
    'STATE/UT': 'Himachal Pradesh',
    'DISTRICT': "Baddi",
    **mean_values_hp1.to_dict()
}])

data_district = data_district[~mask_hp1]
data_district = pd.concat([data_district, new_row_hp1], ignore_index=True)

# G.R.P.
mask_hp2 = data_district["DISTRICT"].isin(["G.R.P.", "GRP Himachal"])
mean_values_hp2 = data_district[mask_hp2].mean(numeric_only=True)

new_row_hp2 = pd.DataFrame([{
    'STATE/UT': 'Himachal Pradesh',
    'DISTRICT': "G.R.P.",
    **mean_values_hp2.to_dict()
}])

data_district = data_district[~mask_hp2]
data_district = pd.concat([data_district, new_row_hp2], ignore_index=True)

# Cid
mask_hp3 = data_district["DISTRICT"].isin(["Cid", "CID HP"])
mean_values_hp3 = data_district[mask_hp3].mean(numeric_only=True)

new_row_hp3 = pd.DataFrame([{
    'STATE/UT': 'Himachal Pradesh',
    'DISTRICT': "Cid",
    **mean_values_hp3.to_dict()
}])

data_district = data_district[~mask_hp3]
data_district = pd.concat([data_district, new_row_hp3], ignore_index=True)

# Jammu & Kashmir
# Border
mask_jk1 = data_district["DISTRICT"].isin(["Border", "Border District"])
mean_values_jk1 = data_district[mask_jk1].mean(numeric_only=True)

new_row_jk1 = pd.DataFrame([{
    'STATE/UT': 'Jammu & Kashmir',
    'DISTRICT': "Border",
    **mean_values_jk1.to_dict()
}])

data_district = data_district[~mask_jk1]
data_district = pd.concat([data_district, new_row_jk1], ignore_index=True)

# Crime
mask_jk2 = data_district["DISTRICT"].isin(["Crime Jammu", "Crime Kashmir", "Crime Srinagar"])
mean_values_jk2 = data_district[mask_jk2].mean(numeric_only=True)

new_row_jk2 = pd.DataFrame([{
    'STATE/UT': 'Jammu & Kashmir',
    'DISTRICT': "Crime",
    **mean_values_jk2.to_dict()
}])

data_district = data_district[~mask_jk2]
data_district = pd.concat([data_district, new_row_jk2], ignore_index=True)

# Railways
mask_jk3 = data_district["DISTRICT"].isin(["Railways", "Railways Jammu", "Railways Kashmir", "Railways Katra", "Railways Kmr"])
mean_values_jk3 = data_district[mask_jk3].mean(numeric_only=True)

new_row_jk3 = pd.DataFrame([{
    'STATE/UT': 'Jammu & Kashmir',
    'DISTRICT': "Railways",
    **mean_values_jk3.to_dict()
}])

data_district = data_district[~mask_jk3]
data_district = pd.concat([data_district, new_row_jk3], ignore_index=True)

# Jharkhand
# Dhanbad
mask_jh1 = data_district["DISTRICT"].isin(["Dhanbad", "Dhanbad Rly."])
mean_values_jh1 = data_district[mask_jh1].mean(numeric_only=True)

new_row_jh1 = pd.DataFrame([{
    'STATE/UT': 'Jharkhand',
    'DISTRICT': "Dhanbad",
    **mean_values_jh1.to_dict()
}])

data_district = data_district[~mask_jh1]
data_district = pd.concat([data_district, new_row_jh1], ignore_index=True)

# Jamshedpur
mask_jh2 = data_district["DISTRICT"].isin(["Jamshedpur", "Jamshedpur Rly."])
mean_values_jh2 = data_district[mask_jh2].mean(numeric_only=True)

new_row_jh2 = pd.DataFrame([{
    'STATE/UT': 'Jharkhand',
    'DISTRICT': "Jamshedpur",
    **mean_values_jh2.to_dict()
}])

data_district = data_district[~mask_jh2]
data_district = pd.concat([data_district, new_row_jh2], ignore_index=True)

# Karnataka
# Bangalore
mask_ka1 = data_district["DISTRICT"].isin(["Bangalore Commr.", "Bangalore Rural"])
mean_values_ka1 = data_district[mask_ka1].mean(numeric_only=True)

new_row_ka1 = pd.DataFrame([{
    'STATE/UT': 'Karnataka',
    'DISTRICT': "Bangalore",
    **mean_values_ka1.to_dict()
}])

data_district = data_district[~mask_ka1]
data_district = pd.concat([data_district, new_row_ka1], ignore_index=True)

# Dharwad
mask_ka2 = data_district["DISTRICT"].isin(["Dharwad Commr.", "Dharwad Rural"])
mean_values_ka2 = data_district[mask_ka2].mean(numeric_only=True)

new_row_ka2 = pd.DataFrame([{
    'STATE/UT': 'Karnataka',
    'DISTRICT': "Dharwad",
    **mean_values_ka2.to_dict()
}])

data_district = data_district[~mask_ka2]
data_district = pd.concat([data_district, new_row_ka2], ignore_index=True)

# Mysore
mask_ka3 = data_district["DISTRICT"].isin(["Mysore Commr.", "Mysore Rural"])
mean_values_ka3 = data_district[mask_ka3].mean(numeric_only=True)

new_row_ka3 = pd.DataFrame([{
    'STATE/UT': 'Karnataka',
    'DISTRICT': "Mysore",
    **mean_values_ka3.to_dict()
}])

data_district = data_district[~mask_ka3]
data_district = pd.concat([data_district, new_row_ka3], ignore_index=True)

# Kerala
# Ernakulam
mask_kl1 = data_district["DISTRICT"].isin(["Ernakulam Commr.", "Ernakulam Rural"])
mean_values_kl1 = data_district[mask_kl1].mean(numeric_only=True)

new_row_kl1 = pd.DataFrame([{
    'STATE/UT': 'Kerala',
    'DISTRICT': "Ernakulam",
    **mean_values_kl1.to_dict()
}])

data_district = data_district[~mask_kl1]
data_district = pd.concat([data_district, new_row_kl1], ignore_index=True)

# Kollam
mask_kl2 = data_district["DISTRICT"].isin(["Kollam Commr.", "Kollam Rural"])
mean_values_kl2 = data_district[mask_kl2].mean(numeric_only=True)

new_row_kl2 = pd.DataFrame([{
    'STATE/UT': 'Kerala',
    'DISTRICT': "Kollam",
    **mean_values_kl2.to_dict()
}])

data_district = data_district[~mask_kl2]
data_district = pd.concat([data_district, new_row_kl2], ignore_index=True)

# Kozhikode
mask_kl3 = data_district["DISTRICT"].isin(["Kozhikode Commr.", "Kozhikode Rural"])
mean_values_kl3 = data_district[mask_kl3].mean(numeric_only=True)

new_row_kl3 = pd.DataFrame([{
    'STATE/UT': 'Kerala',
    'DISTRICT': "Kozhikode",
    **mean_values_kl3.to_dict()
}])

data_district = data_district[~mask_kl3]
data_district = pd.concat([data_district, new_row_kl3], ignore_index=True)

# Thrissur
mask_kl4 = data_district["DISTRICT"].isin(["Thrissur Commr.", "Thrissur Rural"])
mean_values_kl4 = data_district[mask_kl4].mean(numeric_only=True)

new_row_kl4 = pd.DataFrame([{
    'STATE/UT': 'Kerala',
    'DISTRICT': "Thrissur",
    **mean_values_kl4.to_dict()
}])

data_district = data_district[~mask_kl4]
data_district = pd.concat([data_district, new_row_kl4], ignore_index=True)

# Trivandrum
mask_kl5 = data_district["DISTRICT"].isin(["Trivandrum Commr.", "Trivandrum Rural"])
mean_values_kl5 = data_district[mask_kl5].mean(numeric_only=True)

new_row_kl5 = pd.DataFrame([{
    'STATE/UT': 'Kerala',
    'DISTRICT': "Trivandrum",
    **mean_values_kl5.to_dict()
}])

data_district = data_district[~mask_kl5]
data_district = pd.concat([data_district, new_row_kl5], ignore_index=True)

# Madhya Pradesh
# Bhopal
mask_mp1 = data_district["DISTRICT"].isin(["Bhopal", "Bhopal Rly."])
mean_values_mp1 = data_district[mask_mp1].mean(numeric_only=True)

new_row_mp1 = pd.DataFrame([{
    'STATE/UT': 'Madhya Pradesh',
    'DISTRICT': "Bhopal",
    **mean_values_mp1.to_dict()
}])

data_district = data_district[~mask_mp1]
data_district = pd.concat([data_district, new_row_mp1], ignore_index=True)

# Indore
mask_mp2 = data_district["DISTRICT"].isin(["Indore", "Indore Rly."])
mean_values_mp2 = data_district[mask_mp2].mean(numeric_only=True)

new_row_mp2 = pd.DataFrame([{
    'STATE/UT': 'Madhya Pradesh',
    'DISTRICT': "Indore",
    **mean_values_mp2.to_dict()
}])

data_district = data_district[~mask_mp2]
data_district = pd.concat([data_district, new_row_mp2], ignore_index=True)

# Jabalpur
mask_mp3 = data_district["DISTRICT"].isin(["Jabalpur", "Jabalpur Rly."])
mean_values_mp3 = data_district[mask_mp3].mean(numeric_only=True)

new_row_mp3 = pd.DataFrame([{
    'STATE/UT': 'Madhya Pradesh',
    'DISTRICT': "Jabalpur",
    **mean_values_mp3.to_dict()
}])

data_district = data_district[~mask_mp3]
data_district = pd.concat([data_district, new_row_mp3], ignore_index=True)

# Maharashtra
# Amravati
mask_mh1 = data_district["DISTRICT"].isin(["Amravati Commr.", "Amravati Rural"])
mean_values_mh1 = data_district[mask_mh1].mean(numeric_only=True)

new_row_mh1 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Amravati",
    **mean_values_mh1.to_dict()
}])

data_district = data_district[~mask_mh1]
data_district = pd.concat([data_district, new_row_mh1], ignore_index=True)

# Aurangabad
mask_mh2 = data_district["DISTRICT"].isin(["Aurangabad Commr.", "Aurangabad Rural"])
mean_values_mh2 = data_district[mask_mh2].mean(numeric_only=True)

new_row_mh2 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Aurangabad",
    **mean_values_mh2.to_dict()
}])

data_district = data_district[~mask_mh2]
data_district = pd.concat([data_district, new_row_mh2], ignore_index=True)

# Mumbai
mask_mh3 = data_district["DISTRICT"].isin(["Mumbai", "Mumbai Commr.", "Mumbai Rly."])
mean_values_mh3 = data_district[mask_mh3].mean(numeric_only=True)

new_row_mh3 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Mumbai",
    **mean_values_mh3.to_dict()
}])

data_district = data_district[~mask_mh3]
data_district = pd.concat([data_district, new_row_mh3], ignore_index=True)

# Nagpur
mask_mh4 = data_district["DISTRICT"].isin(["Nagpur Commr.", "Nagpur Rly.", "Nagpur Rural"])
mean_values_mh4 = data_district[mask_mh4].mean(numeric_only=True)

new_row_mh4 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Nagpur",
    **mean_values_mh4.to_dict()
}])

data_district = data_district[~mask_mh4]
data_district = pd.concat([data_district, new_row_mh4], ignore_index=True)

# Nasik
mask_mh5 = data_district["DISTRICT"].isin(["Nasik Commr.", "Nasik Rural"])
mean_values_mh5 = data_district[mask_mh5].mean(numeric_only=True)

new_row_mh5 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Nasik",
    **mean_values_mh5.to_dict()
}])

data_district = data_district[~mask_mh5]
data_district = pd.concat([data_district, new_row_mh5], ignore_index=True)

# Pune
mask_mh6 = data_district["DISTRICT"].isin(["Pune Commr.", "Pune Rly.", "Pune Rural"])
mean_values_mh6 = data_district[mask_mh6].mean(numeric_only=True)

new_row_mh6 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Pune",
    **mean_values_mh6.to_dict()
}])

data_district = data_district[~mask_mh6]
data_district = pd.concat([data_district, new_row_mh6], ignore_index=True)

# Solapur
mask_mh7 = data_district["DISTRICT"].isin(["Solapur Commr.", "Solapur Rural"])
mean_values_mh7 = data_district[mask_mh7].mean(numeric_only=True)

new_row_mh7 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Solapur",
    **mean_values_mh7.to_dict()
}])

data_district = data_district[~mask_mh7]
data_district = pd.concat([data_district, new_row_mh7], ignore_index=True)

# Thane
mask_mh8 = data_district["DISTRICT"].isin(["Thane Commr.", "Thane Rural"])
mean_values_mh8 = data_district[mask_mh8].mean(numeric_only=True)

new_row_mh8 = pd.DataFrame([{
    'STATE/UT': 'Maharashtra',
    'DISTRICT': "Thane",
    **mean_values_mh8.to_dict()
}])

data_district = data_district[~mask_mh8]
data_district = pd.concat([data_district, new_row_mh8], ignore_index=True)

# Manipur
# Imphal East
mask_mn1 = data_district["DISTRICT"].isin(["Imphal East", "Imphal(East)"])
mean_values_mn1 = data_district[mask_mn1].mean(numeric_only=True)

new_row_mn1 = pd.DataFrame([{
    'STATE/UT': 'Manipur',
    'DISTRICT': "Imphal East",
    **mean_values_mn1.to_dict()
}])

data_district = data_district[~mask_mn1]
data_district = pd.concat([data_district, new_row_mn1], ignore_index=True)

# Imphal West
mask_mn2 = data_district["DISTRICT"].isin(["Imphal West", "Imphal(West)"])
mean_values_mn2 = data_district[mask_mn2].mean(numeric_only=True)

new_row_mn2 = pd.DataFrame([{
    'STATE/UT': 'Manipur',
    'DISTRICT': "Imphal West",
    **mean_values_mn2.to_dict()
}])

data_district = data_district[~mask_mn2]
data_district = pd.concat([data_district, new_row_mn2], ignore_index=True)

# Meghalaya
# Garo Hills
mask_ml1 = data_district["DISTRICT"].isin(["Garo Hills East", "Garo Hills South", "Garo Hills West"])
mean_values_ml1 = data_district[mask_ml1].mean(numeric_only=True)

new_row_ml1 = pd.DataFrame([{
    'STATE/UT': 'Meghalaya',
    'DISTRICT': "Garo Hills",
    **mean_values_ml1.to_dict()
}])

data_district = data_district[~mask_ml1]
data_district = pd.concat([data_district, new_row_ml1], ignore_index=True)

# Khasi Hills
mask_ml2 = data_district["DISTRICT"].isin(["Khasi Hills East", "Khasi Hills West"])
mean_values_ml2 = data_district[mask_ml2].mean(numeric_only=True)

new_row_ml2 = pd.DataFrame([{
    'STATE/UT': 'Meghalaya',
    'DISTRICT': "Khasi Hills",
    **mean_values_ml2.to_dict()
}])

data_district = data_district[~mask_ml2]
data_district = pd.concat([data_district, new_row_ml2], ignore_index=True)

# Odisha
# Cuttack
mask_od1 = data_district["DISTRICT"].isin(["Cuttack", "Dcp Ctc", "Srp(Cuttack)"])
mean_values_od1 = data_district[mask_od1].mean(numeric_only=True)

new_row_od1 = pd.DataFrame([{
    'STATE/UT': 'Odisha',
    'DISTRICT': "Cuttack",
    **mean_values_od1.to_dict()
}])

data_district = data_district[~mask_od1]
data_district = pd.concat([data_district, new_row_od1], ignore_index=True)

# Bhubaneswar
mask_od2 = data_district["DISTRICT"].isin(["Dcp Bbsr"])
mean_values_od2 = data_district[mask_od2].mean(numeric_only=True)

new_row_od2 = pd.DataFrame([{
    'STATE/UT': 'Odisha',
    'DISTRICT': "Bhubaneswar",
    **mean_values_od2.to_dict()
}])

data_district = data_district[~mask_od2]
data_district = pd.concat([data_district, new_row_od2], ignore_index=True)

# Rourkela
mask_od3 = data_district["DISTRICT"].isin(["Rourkela", "Srp(Rourkela)"])
mean_values_od3 = data_district[mask_od3].mean(numeric_only=True)

new_row_od3 = pd.DataFrame([{
    'STATE/UT': 'Odisha',
    'DISTRICT': "Rourkela",
    **mean_values_od3.to_dict()
}])

data_district = data_district[~mask_od3]
data_district = pd.concat([data_district, new_row_od3], ignore_index=True)

# Punjab
# Amritsar
mask_pb1 = data_district["DISTRICT"].isin(["Amritsar", "Amritsar Rural", "Cp Amritsar"])
mean_values_pb1 = data_district[mask_pb1].mean(numeric_only=True)

new_row_pb1 = pd.DataFrame([{
    'STATE/UT': 'Punjab',
    'DISTRICT': "Amritsar",
    **mean_values_pb1.to_dict()
}])

data_district = data_district[~mask_pb1]
data_district = pd.concat([data_district, new_row_pb1], ignore_index=True)

# Jalandhar
mask_pb2 = data_district["DISTRICT"].isin(["Jalandhar", "Jalandhar Rural", "Cp Jalandhar"])
mean_values_pb2 = data_district[mask_pb2].mean(numeric_only=True)

new_row_pb2 = pd.DataFrame([{
    'STATE/UT': 'Punjab',
    'DISTRICT': "Jalandhar",
    **mean_values_pb2.to_dict()
}])

data_district = data_district[~mask_pb2]
data_district = pd.concat([data_district, new_row_pb2], ignore_index=True)

# Ludhiana
mask_pb3 = data_district["DISTRICT"].isin(["Ludhiana", "Ludhiana Rural", "Cp Ludhiana"])
mean_values_pb3 = data_district[mask_pb3].mean(numeric_only=True)

new_row_pb3 = pd.DataFrame([{
    'STATE/UT': 'Punjab',
    'DISTRICT': "Ludhiana",
    **mean_values_pb3.to_dict()
}])

data_district = data_district[~mask_pb3]
data_district = pd.concat([data_district, new_row_pb3], ignore_index=True)

# Ferozepur
mask_pb4 = data_district["DISTRICT"].isin(["Ferozepur", "Ferozpur"])
mean_values_pb4 = data_district[mask_pb4].mean(numeric_only=True)

new_row_pb4 = pd.DataFrame([{
    'STATE/UT': 'Punjab',
    'DISTRICT': "Ferozepur",
    **mean_values_pb4.to_dict()
}])

data_district = data_district[~mask_pb4]
data_district = pd.concat([data_district, new_row_pb4], ignore_index=True)

# Shaheed Bhagat Singh Nagar
mask_pb5 = data_district["DISTRICT"].isin(["Sbs Nagar", "Nawan Shahr"])
mean_values_pb5 = data_district[mask_pb5].mean(numeric_only=True)

new_row_pb5 = pd.DataFrame([{
    'STATE/UT': 'Punjab',
    'DISTRICT': "Shaheed Bhagat Singh Nagar",
    **mean_values_pb5.to_dict()
}])

data_district = data_district[~mask_pb5]
data_district = pd.concat([data_district, new_row_pb5], ignore_index=True)

# S.A.S. Nagar
mask_pb6 = data_district["DISTRICT"].isin(["Sas Ngr"])
mean_values_pb6 = data_district[mask_pb6].mean(numeric_only=True)

new_row_pb6 = pd.DataFrame([{
    'STATE/UT': 'Punjab',
    'DISTRICT': "S.A.S. Nagar",
    **mean_values_pb6.to_dict()
}])

data_district = data_district[~mask_pb6]
data_district = pd.concat([data_district, new_row_pb6], ignore_index=True)

# Rajasthan
# G.R.P. Ajmer
mask_rj1 = data_district["DISTRICT"].isin(["G.R.P. Ajmer", "G.R.P.Ajmer"])
mean_values_rj1 = data_district[mask_rj1].mean(numeric_only=True)

new_row_rj1 = pd.DataFrame([{
    'STATE/UT': 'Rajasthan',
    'DISTRICT': "G.R.P. Ajmer",
    **mean_values_rj1.to_dict()
}])

data_district = data_district[~mask_rj1]
data_district = pd.concat([data_district, new_row_rj1], ignore_index=True)

# G.R.P. Jodhpur
mask_rj2 = data_district["DISTRICT"].isin(["G.R.P. Jodhpur", "G.R.P.Jodhpur"])
mean_values_rj2 = data_district[mask_rj2].mean(numeric_only=True)

new_row_rj2 = pd.DataFrame([{
    'STATE/UT': 'Rajasthan',
    'DISTRICT': "G.R.P. Jodhpur",
    **mean_values_rj2.to_dict()
}])

data_district = data_district[~mask_rj2]
data_district = pd.concat([data_district, new_row_rj2], ignore_index=True)

# Jaipur
mask_rj3 = data_district["DISTRICT"].isin(["Jaipur", "Jaipur East", "Jaipur North", "Jaipur Rural", "Jaipur South", "Jaipur West"])
mean_values_rj3 = data_district[mask_rj3].mean(numeric_only=True)

new_row_rj3 = pd.DataFrame([{
    'STATE/UT': 'Rajasthan',
    'DISTRICT': "Jaipur",
    **mean_values_rj3.to_dict()
}])

data_district = data_district[~mask_rj3]
data_district = pd.concat([data_district, new_row_rj3], ignore_index=True)

# Jodhpur
mask_rj4 = data_district["DISTRICT"].isin(["Jodhpur", "Jodhpur City", "Jodhpur East", "Jodhpur Rural", "Jodhpur West"])
mean_values_rj4 = data_district[mask_rj4].mean(numeric_only=True)

new_row_rj4 = pd.DataFrame([{
    'STATE/UT': 'Rajasthan',
    'DISTRICT': "Jodhpur",
    **mean_values_rj4.to_dict()
}])

data_district = data_district[~mask_rj4]
data_district = pd.concat([data_district, new_row_rj4], ignore_index=True)

# Kota
mask_rj5 = data_district["DISTRICT"].isin(["Kota", "Kota City", "Kota Rural"])
mean_values_rj5 = data_district[mask_rj5].mean(numeric_only=True)

new_row_rj5 = pd.DataFrame([{
    'STATE/UT': 'Rajasthan',
    'DISTRICT': "Kota",
    **mean_values_rj5.to_dict()
}])

data_district = data_district[~mask_rj5]
data_district = pd.concat([data_district, new_row_rj5], ignore_index=True)

# Tamil Nadu
# Chennai
mask_tn1 = data_district["DISTRICT"].isin(["Chennai", "Chennai Rly.", "Chennaisuburban"])
mean_values_tn1 = data_district[mask_tn1].mean(numeric_only=True)

new_row_tn1 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Chennai",
    **mean_values_tn1.to_dict()
}])

data_district = data_district[~mask_tn1]
data_district = pd.concat([data_district, new_row_tn1], ignore_index=True)

# Coimbatore
mask_tn2 = data_district["DISTRICT"].isin(["Coimbatore Rural", "Coimbatore Urban"])
mean_values_tn2 = data_district[mask_tn2].mean(numeric_only=True)

new_row_tn2 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Coimbatore",
    **mean_values_tn2.to_dict()
}])

data_district = data_district[~mask_tn2]
data_district = pd.concat([data_district, new_row_tn2], ignore_index=True)

# Madurai
mask_tn3 = data_district["DISTRICT"].isin(["Madurai Rural", "Madurai Urban"])
mean_values_tn3 = data_district[mask_tn3].mean(numeric_only=True)

new_row_tn3 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Madurai",
    **mean_values_tn3.to_dict()
}])

data_district = data_district[~mask_tn3]
data_district = pd.concat([data_district, new_row_tn3], ignore_index=True)

# Salem
mask_tn4 = data_district["DISTRICT"].isin(["Salem Rural", "Salem Urban"])
mean_values_tn4 = data_district[mask_tn4].mean(numeric_only=True)

new_row_tn4 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Salem",
    **mean_values_tn4.to_dict()
}])

data_district = data_district[~mask_tn4]
data_district = pd.concat([data_district, new_row_tn4], ignore_index=True)

# Thirunelveli
mask_tn5 = data_district["DISTRICT"].isin(["Thirunelveli Rural", "Thirunelveli Urban"])
mean_values_tn5 = data_district[mask_tn5].mean(numeric_only=True)

new_row_tn5 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Thirunelveli",
    **mean_values_tn5.to_dict()
}])

data_district = data_district[~mask_tn5]
data_district = pd.concat([data_district, new_row_tn5], ignore_index=True)

# Trichy
mask_tn6 = data_district["DISTRICT"].isin(["Trichy Rly.", "Trichy Rural", "Trichy Urban"])
mean_values_tn6 = data_district[mask_tn6].mean(numeric_only=True)

new_row_tn6 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Trichy",
    **mean_values_tn6.to_dict()
}])

data_district = data_district[~mask_tn6]
data_district = pd.concat([data_district, new_row_tn6], ignore_index=True)

# Villupuram
mask_tn7 = data_district["DISTRICT"].isin(["Villupuram", "Viluppuram"])
mean_values_tn7 = data_district[mask_tn7].mean(numeric_only=True)

new_row_tn7 = pd.DataFrame([{
    'STATE/UT': 'Tamil Nadu',
    'DISTRICT': "Villupuram",
    **mean_values_tn7.to_dict()
}])

data_district = data_district[~mask_tn7]
data_district = pd.concat([data_district, new_row_tn7], ignore_index=True)

# Tripura - Merging duplicate districts
mask_tripura = data_district["DISTRICT"].isin(["G.R.P.", "Grp"])
mean_values_tripura = data_district[mask_tripura].mean(numeric_only=True)

new_row_tripura = pd.DataFrame([{
    'STATE/UT': 'Tripura',
    'DISTRICT': "G.R.P.",
    **mean_values_tripura.to_dict()
}])

data_district = data_district[~mask_tripura]
data_district = pd.concat([data_district, new_row_tripura], ignore_index=True)

# Uttar Pradesh - Merging duplicate districts

# G.R.P. (Keeping it separate)
mask_up1 = data_district["DISTRICT"].isin(["G.R.P."])
mean_values_up1 = data_district[mask_up1].mean(numeric_only=True)
new_row_up1 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "G.R.P.",
    **mean_values_up1.to_dict()
}])
data_district = data_district[~mask_up1]
data_district = pd.concat([data_district, new_row_up1], ignore_index=True)

# Ambedkar Nagar
mask_up2 = data_district["DISTRICT"].isin(["Ambedkar Nagar", "Ramabai Nagar"])
mean_values_up2 = data_district[mask_up2].mean(numeric_only=True)
new_row_up2 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Ambedkar Nagar",
    **mean_values_up2.to_dict()
}])
data_district = data_district[~mask_up2]
data_district = pd.concat([data_district, new_row_up2], ignore_index=True)

# Chitrakoot
mask_up3 = data_district["DISTRICT"].isin(["Chitrakoot", "Chitrakoot Dham"])
mean_values_up3 = data_district[mask_up3].mean(numeric_only=True)
new_row_up3 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Chitrakoot",
    **mean_values_up3.to_dict()
}])
data_district = data_district[~mask_up3]
data_district = pd.concat([data_district, new_row_up3], ignore_index=True)

# Amethi
mask_up4 = data_district["DISTRICT"].isin(["Amethi", "Csm Nagar"])
mean_values_up4 = data_district[mask_up4].mean(numeric_only=True)
new_row_up4 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Amethi",
    **mean_values_up4.to_dict()
}])
data_district = data_district[~mask_up4]
data_district = pd.concat([data_district, new_row_up4], ignore_index=True)

# Shahjahanpur
mask_up5 = data_district["DISTRICT"].isin(["Shahjahanpur", "Panchshil Nagar"])
mean_values_up5 = data_district[mask_up5].mean(numeric_only=True)
new_row_up5 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Shahjahanpur",
    **mean_values_up5.to_dict()
}])
data_district = data_district[~mask_up5]
data_district = pd.concat([data_district, new_row_up5], ignore_index=True)

# Sant Ravidas Nagar
mask_up6 = data_district["DISTRICT"].isin(["Sant Ravidas Nagar", "St.Ravidasnagar"])
mean_values_up6 = data_district[mask_up6].mean(numeric_only=True)
new_row_up6 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Sant Ravidas Nagar",
    **mean_values_up6.to_dict()
}])
data_district = data_district[~mask_up6]
data_district = pd.concat([data_district, new_row_up6], ignore_index=True)

# JP Nagar
mask_up7 = data_district["DISTRICT"].isin(["JP Nagar", "J.P.Nagar"])
mean_values_up7 = data_district[mask_up7].mean(numeric_only=True)
new_row_up7 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "JP Nagar",
    **mean_values_up7.to_dict()
}])
data_district = data_district[~mask_up7]
data_district = pd.concat([data_district, new_row_up7], ignore_index=True)

# Kanshiram Nagar
mask_up8 = data_district["DISTRICT"].isin(["Kanshiram Nagar", "Kasganj"])
mean_values_up8 = data_district[mask_up8].mean(numeric_only=True)
new_row_up8 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Kanshiram Nagar",
    **mean_values_up8.to_dict()
}])
data_district = data_district[~mask_up8]
data_district = pd.concat([data_district, new_row_up8], ignore_index=True)

# Hapur
mask_up9 = data_district["DISTRICT"].isin(["Hapur", "Panchshil Nagar"])
mean_values_up9 = data_district[mask_up9].mean(numeric_only=True)
new_row_up9 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Hapur",
    **mean_values_up9.to_dict()
}])
data_district = data_district[~mask_up9]
data_district = pd.concat([data_district, new_row_up9], ignore_index=True)

# Shamli
mask_up10 = data_district["DISTRICT"].isin(["Shamli", "Prabuddh Nagar"])
mean_values_up10 = data_district[mask_up10].mean(numeric_only=True)
new_row_up10 = pd.DataFrame([{
    'STATE/UT': 'Uttar Pradesh',
    'DISTRICT': "Shamli",
    **mean_values_up10.to_dict()
}])
data_district = data_district[~mask_up10]
data_district = pd.concat([data_district, new_row_up10], ignore_index=True)

# West Bengal - Merging Duplicate Districts

# 24 Parganas (North & South)
mask_wb1 = data_district["DISTRICT"].isin(["24 Parganas North", "24 Parganas South"])
mean_values_wb1 = data_district[mask_wb1].mean(numeric_only=True)

new_row_wb1 = pd.DataFrame([{
    'STATE/UT': 'West Bengal',
    'DISTRICT': "24 Parganas",
    **mean_values_wb1.to_dict()
}])

data_district = data_district[~mask_wb1]
data_district = pd.concat([data_district, new_row_wb1], ignore_index=True)

# Burdwan (Merging with Paschim & Purab Midnapur)
mask_wb2 = data_district["DISTRICT"].isin(["Burdwan", "Paschim Midnapur", "Purab Midnapur"])
mean_values_wb2 = data_district[mask_wb2].mean(numeric_only=True)

new_row_wb2 = pd.DataFrame([{
    'STATE/UT': 'West Bengal',
    'DISTRICT': "Burdwan",
    **mean_values_wb2.to_dict()
}])

data_district = data_district[~mask_wb2]
data_district = pd.concat([data_district, new_row_wb2], ignore_index=True)

# Howrah (Including Howrah City & Howrah G.R.P.)
mask_wb3 = data_district["DISTRICT"].isin(["Howrah", "Howrah City", "Howrah G.R.P."])
mean_values_wb3 = data_district[mask_wb3].mean(numeric_only=True)

new_row_wb3 = pd.DataFrame([{
    'STATE/UT': 'West Bengal',
    'DISTRICT': "Howrah",
    **mean_values_wb3.to_dict()
}])

data_district = data_district[~mask_wb3]
data_district = pd.concat([data_district, new_row_wb3], ignore_index=True)

# Siliguri (Merging G.R.P. & Pc Variants)
mask_wb4 = data_district["DISTRICT"].isin(["Siliguri G.R.P.", "Siliguri_Pc"])
mean_values_wb4 = data_district[mask_wb4].mean(numeric_only=True)

new_row_wb4 = pd.DataFrame([{
    'STATE/UT': 'West Bengal',
    'DISTRICT': "Siliguri",
    **mean_values_wb4.to_dict()
}])

data_district = data_district[~mask_wb4]
data_district = pd.concat([data_district, new_row_wb4], ignore_index=True)

# Kolkata (Merging with Variants)
mask_wb5 = data_district["DISTRICT"].isin(["Kolkata", "Bkp Cp", "Bdn Cp"])
mean_values_wb5 = data_district[mask_wb5].mean(numeric_only=True)

new_row_wb5 = pd.DataFrame([{
    'STATE/UT': 'West Bengal',
    'DISTRICT': "Kolkata",
    **mean_values_wb5.to_dict()
}])

data_district = data_district[~mask_wb5]
data_district = pd.concat([data_district, new_row_wb5], ignore_index=True)

# Midnapur (Merging with Paschim & Purab Midnapur)
mask_wb6 = data_district["DISTRICT"].isin(["Midnapur", "Paschim Midnapur", "Purab Midnapur"])
mean_values_wb6 = data_district[mask_wb6].mean(numeric_only=True)

new_row_wb6 = pd.DataFrame([{
    'STATE/UT': 'West Bengal',
    'DISTRICT': "Midnapur",
    **mean_values_wb6.to_dict()
}])

data_district = data_district[~mask_wb6]
data_district = pd.concat([data_district, new_row_wb6], ignore_index=True)

# Puducherry - Merging Duplicate Districts

mask_puducherry = data_district["DISTRICT"].isin(["Pondicherry", "Puducherry"])
mean_values_puducherry = data_district[mask_puducherry].mean(numeric_only=True)

new_row_puducherry = pd.DataFrame([{
    'STATE/UT': 'Puducherry',
    'DISTRICT': "Puducherry",
    **mean_values_puducherry.to_dict()
}])

data_district = data_district[~mask_puducherry]
data_district = pd.concat([data_district, new_row_puducherry], ignore_index=True)

import pandas as pd

# Assuming 'data_district' is your DataFrame containing district-wise data.

# Delhi UT - Merging Duplicate/Variant District Names

# North Delhi (Merging North, North-East, North-West)
mask_delhi1 = data_district["DISTRICT"].isin(["North", "North East", "North West", "North-East", "North-West"])
mean_values_delhi1 = data_district[mask_delhi1].mean(numeric_only=True)

new_row_delhi1 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "North Delhi",
    **mean_values_delhi1.to_dict()
}])

data_district = data_district[~mask_delhi1]
data_district = pd.concat([data_district, new_row_delhi1], ignore_index=True)

# South Delhi (Merging South, South-East, South-West)
mask_delhi2 = data_district["DISTRICT"].isin(["South", "South East", "South West", "South-East", "South-West"])
mean_values_delhi2 = data_district[mask_delhi2].mean(numeric_only=True)

new_row_delhi2 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "South Delhi",
    **mean_values_delhi2.to_dict()
}])

data_district = data_district[~mask_delhi2]
data_district = pd.concat([data_district, new_row_delhi2], ignore_index=True)

# Central Delhi (Merging Central & New Delhi)
mask_delhi3 = data_district["DISTRICT"].isin(["Central", "New Delhi"])
mean_values_delhi3 = data_district[mask_delhi3].mean(numeric_only=True)

new_row_delhi3 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "Central Delhi",
    **mean_values_delhi3.to_dict()
}])

data_district = data_district[~mask_delhi3]
data_district = pd.concat([data_district, new_row_delhi3], ignore_index=True)

# West Delhi (Merging West & Outer)
mask_delhi4 = data_district["DISTRICT"].isin(["West", "Outer"])
mean_values_delhi4 = data_district[mask_delhi4].mean(numeric_only=True)

new_row_delhi4 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "West Delhi",
    **mean_values_delhi4.to_dict()
}])

data_district = data_district[~mask_delhi4]
data_district = pd.concat([data_district, new_row_delhi4], ignore_index=True)

# Special Units (Merging STF, Spl Cell, EOW, Crime Branch)
mask_delhi5 = data_district["DISTRICT"].isin(["S.T.F.", "Stf", "Spl Cell", "Eow", "Crime Branch"])
mean_values_delhi5 = data_district[mask_delhi5].mean(numeric_only=True)

new_row_delhi5 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "Special Units",
    **mean_values_delhi5.to_dict()
}])

data_district = data_district[~mask_delhi5]
data_district = pd.concat([data_district, new_row_delhi5], ignore_index=True)

# Railway Units (Merging GRP Variants)
mask_delhi6 = data_district["DISTRICT"].isin(["G.R.P.(Rly)", "Grp(Rly)"])
mean_values_delhi6 = data_district[mask_delhi6].mean(numeric_only=True)

new_row_delhi6 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "Railway Units",
    **mean_values_delhi6.to_dict()
}])

data_district = data_district[~mask_delhi6]
data_district = pd.concat([data_district, new_row_delhi6], ignore_index=True)

# IGI Airport (Merging Variants)
mask_delhi7 = data_district["DISTRICT"].isin(["I.G.I. Airport", "Igi Airport"])
mean_values_delhi7 = data_district[mask_delhi7].mean(numeric_only=True)

new_row_delhi7 = pd.DataFrame([{
    'STATE/UT': 'Delhi Ut',
    'DISTRICT': "IGI Airport",
    **mean_values_delhi7.to_dict()
}])

data_district = data_district[~mask_delhi7]
data_district = pd.concat([data_district, new_row_delhi7], ignore_index=True)
# removal done
data_district.rename(columns={"MURDER.1": "MURDER"}, inplace=True)
data_district.rename(columns={"RAPE.1": "RAPE"}, inplace=True)
data_district.rename(columns={"KIDNAPPING & ABDUCTION.1": "KIDNAPPING & ABDUCTION"}, inplace=True)

data_district["TOTAL CRIME"] = (data_district["MURDER"] + data_district["RAPE"] + data_district["KIDNAPPING & ABDUCTION"] + data_district["ROBBERY & THEFT"] + data_district["VIOLENCE AGAINST WOMEN"] 
                                + data_district["FRAUD & FINANCIAL CRIMES"])

data_district["YEAR"] = data_district["YEAR"].fillna(data_district["YEAR"].median()).astype(int)

#ML Model
Crime_Predictions = ['MURDER', 'RAPE', 'KIDNAPPING & ABDUCTION', 'ROBBERY & THEFT', 
                     'VIOLENCE AGAINST WOMEN', 'FRAUD & FINANCIAL CRIMES']

# Fill NaN values with 0 before taking the max
data_district[Crime_Predictions] = data_district[Crime_Predictions].fillna(0)

# Identify most frequent crime per row
data_district["COMMON_CRIMES"] = data_district[Crime_Predictions].idxmax(axis=1)

# Define features (X) and target (y)
X = data_district[["STATE/UT", "DISTRICT", "YEAR"]]
y = data_district["COMMON_CRIMES"].dropna()

# One-Hot Encoding for categorical features
encoder = OHE(handle_unknown='ignore', sparse_output=False)
X_encoded = encoder.fit_transform(X)

# Convert encoded data to DataFrame
X_encoded = pd.DataFrame(X_encoded, columns=encoder.get_feature_names_out(X.columns))

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42, stratify=y)

# Train Random Forest Classifier for Crime Type Prediction
type_model = RandomForestClassifier(n_estimators=200, random_state=42, class_weight = "balanced")
type_model.fit(X_train, y_train)

# Predict on test set
y_pred = type_model.predict(X_test)
def get_ranked_crimes(probabilities, labels):
    crime_probs = dict(zip(labels, probabilities))
    ranked_crimes = sorted(crime_probs.items(), key=lambda x: x[1], reverse=True)
    return ranked_crimes  # List of tuples [(crime, probability), ...]


# Evaluate model accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"🔹 Crime Type Prediction Accuracy (Random Forest): {accuracy:.2f}")

joblib.dump(type_model, "crime_type_prediction_model.pkl")
joblib.dump(encoder, "encoder.pkl")

print("Model and Encoder saved successfully!")

#make side bar
st.title("Crime Analysis in Indian Cities")
st.sidebar.title(" Crime Analysis Dashboard")
selected_feature = st.sidebar.radio("Go to",["🏠 Home","📊 Crime Bar Chart","📌 State Crime Distribution","🔎 Frequent Crimes","🤖 Crime Prediction"])
#Home
if selected_feature == "🏠 Home":
    st.write(
        """
        Welcome to the **Crime Analysis & Prediction Dashboard**!  
        This tool allows users to explore crime trends across various states and cities, visualize hotspots,  
        and even predict potential crime-prone areas using **Machine Learning**.  
        
        ### 🔍 Features:
        - **📊 Crime Bar Chart:** Analyze crime distribution in cities.
        - **📌 State Crime Distribution:** Compare crime rates within a state.
        - **🔎 Frequent Crimes:** Identify common crimes in a city.
        - **🤖 Crime Prediction (ML):** Rank predicted crime based on their percent of occurence using machine learning.

        Select a feature from the **sidebar** to get started!
        """
    )
#Crime Bar Chart
if selected_feature == "📊 Crime Bar Chart":
    st.header("📊 Crime Bar Chart")
    select_state = st.selectbox("Select  State", ["Select State"] + sorted(data_district["STATE/UT"].unique()))
    choose_city = sorted(data_district[data_district["STATE/UT"] == select_state]["DISTRICT"].unique())
    select_city = st.selectbox("Select City", ["Select City"] + choose_city)

    filtered_df = data_district[(data_district["STATE/UT"] == select_state) & (data_district["DISTRICT"] == select_city)]

    if not filtered_df.empty:  # Execute only if data exists
        numeric_df = filtered_df.select_dtypes(include=['number']).drop(columns=["YEAR", "OTHER CRIMES", "TOTAL CRIME"], errors="ignore")
        avg_crime = numeric_df.mean()  # Calculate average crimes per year

        # Plot the bar chart
        fig, ax = plt.subplots(figsize=(14, 8))
        sns.barplot(x=avg_crime.index, y=avg_crime.values, palette="colorblind", ax=ax)
        wrapped_labels = ['\n'.join(textwrap.wrap(label, width=10)) for label in avg_crime.index]
        ax.set_xticklabels(wrapped_labels)
        ax.set_xlabel("CRIME TYPE")
        ax.set_ylabel("AVERAGE CRIME COUNT OVER THE YEARS")
        ax.set_title(f"Average Crime Count in {select_city}, {select_state} (Over the Years)")

        st.pyplot(fig)  # Show plot in Streamlit

if selected_feature == "📌 State Crime Distribution":
    st.header("📌 State Crime Distribution")
    select_state_ht = st.selectbox("Select  State", sorted(data_district["STATE/UT"].unique()))
    choose_crime = ['MURDER', 'RAPE','KIDNAPPING & ABDUCTION', 'ROBBERY & THEFT', 'VIOLENCE AGAINST WOMEN','FRAUD & FINANCIAL CRIMES']
    if select_state_ht:
        state_data = data_district[(data_district["STATE/UT"] == select_state_ht)]
        avg_crime_rates = state_data[choose_crime].mean().dropna()
        fig, ax = plt.subplots(figsize=(14, 8))
        colours = sns.color_palette("colorblind", len(choose_crime))
        wrapped_labels = [textwrap.fill(label, width=15) for label in choose_crime]
        ax.pie(avg_crime_rates, labels = wrapped_labels, autopct="%1.1f%%", startangle=90, colors= colours, textprops = {'fontsize' : 7})
        ax.set_title(f" Avg. Crime Rate Distribution in {select_state_ht} (over the years)")

    # Show the pie chart in Streamlit
        st.pyplot(fig)


if selected_feature == "🔎 Frequent Crimes":
    st.header("🔎 Frequent Crimes")
    select_crime = st.selectbox("Select Crime",["Select Crime"] + ['MURDER', 'RAPE','KIDNAPPING & ABDUCTION', 'ROBBERY & THEFT', 'VIOLENCE AGAINST WOMEN','FRAUD & FINANCIAL CRIMES',"TOTAL CRIME"])
    select_no = st.selectbox("Select Number of States",["Select Number of States"] + [5,10,15,20,25,"All"])
    if select_no == "Select Number of States" or select_crime == "Select Crime":
        st.subheader("")
    elif select_no == "All":
        st.subheader(f"All states ranked on the basis of {select_crime}")
    else:
        st.subheader(f"Top {select_no} states ranked on the basis of {select_crime}")
    if select_crime != "Select Crime" and select_no != "Select Number of States":
        select_crime_total = data_district.groupby("STATE/UT")[select_crime].sum().reset_index()
        rank_states = select_crime_total.sort_values(by = select_crime, ascending = False)
        rank_states[select_crime] = rank_states[select_crime].astype(int)

        if select_no != "All":
            rank_states = rank_states.head(int(select_no))
        st.table(rank_states.set_index("STATE/UT"))

if selected_feature == "🤖 Crime Prediction":
    model = joblib.load("crime_type_prediction_model.pkl")
    encoder = joblib.load("encoder.pkl")
    st.header("🤖 Crime Type Prediction")
    select_state = st.selectbox("Select  State",["Select State"] + sorted(data_district["STATE/UT"].unique()))
    choose_city = sorted(data_district[data_district["STATE/UT"] == select_state]["DISTRICT"].unique())
    select_city = st.selectbox("Select City",["Select City"] + choose_city)
    select_year = st.selectbox("Select Year",["Select Year"] + [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023])
    if st.button("Predict Type"):
        if select_state == "Select State" or select_city == "Select City" or select_year == "Select Year":
            st.warning("⚠️ Please select all fields before predicting.")
        else:
        # Prepare input
            input_data = pd.DataFrame([[select_state, select_city, int(select_year)]], 
                                  columns=['STATE/UT', 'DISTRICT', 'YEAR'])
            input_encoded = encoder.transform(input_data)
            input_encoded_df = pd.DataFrame(input_encoded, columns=encoder.get_feature_names_out(['STATE/UT', 'DISTRICT', 'YEAR']))

        # Get crime probabilities
            crime_labels = np.array(model.classes_)  # Crime types
            crime_probs = model.predict_proba(input_encoded_df)[0]  # Get probability distribution

        # Sort crimes by probability (Descending Order)
            sorted_indices = np.argsort(crime_probs)[::-1]
            sorted_crimes = crime_labels[sorted_indices]
            sorted_probs = crime_probs[sorted_indices] * 100  # Convert to percentage

        # Display ranked crime probabilities
            st.subheader(f"🔮 Crime Probability Rankings for {select_city}, {select_state} in {select_year}")
            for crime, prob in zip(sorted_crimes, sorted_probs):
                st.write(f"**{crime}:** {prob:.2f}%")